;; -*- coding: utf-8-mcs-er -*-
(define-char
  '((shuowen-radical	. 13)	; 蓐
    (=ucs		. #x3D317)	; 𽌗
    (=shuowen-jiguge	. 03109)	; 𽌗
    (<-Small-Seal@shuowen
     ((=ucs		  . #x84D0)	; 蓐
      ))
    (->subsumptive
     ((===shuowen-jiguge-A30 . 03109)	; &SW-JIGUGE30-03109;
      )
     ((===shuowen-jiguge5 . 03109)	; &SW-JIGUGE5-03109;
      )
     ((===shuowen-jiguge4 . 03109)	; &SW-JIGUGE4-03109;
      ))
    ))
(define-char
  '((shuowen-radical	. 13)	; 蓐
    (=ucs		. #x3D318)	; 𽌘
    (=shuowen-jiguge	. 03110)	; 𽌘
    (<-Small-Seal@shuowen
     ((=ucs		  . #x26E33)	; 𦸳
      ))
    (<-Zhouwen@shuowen
     ((=ucs		  . #x3D317)	; 𽌗
      )
     ((=ucs		  . #x84D0)	; 蓐
      ))
    (->subsumptive
     ((===shuowen-jiguge-A30 . 03110)	; &SW-JIGUGE30-03110;
      )
     ((===shuowen-jiguge5 . 03110)	; &SW-JIGUGE5-03110;
      )
     ((===shuowen-jiguge4 . 03110)	; &SW-JIGUGE4-03110;
      ))
    ))
(define-char
  '((shuowen-radical	. 13)	; 蓐
    (=ucs		. #x3D319)	; 𽌙
    (=shuowen-jiguge	. 03111)	; 𽌙
    (<-Small-Seal@shuowen
     ((=ucs		  . #x8585)	; 薅
      ))
    (->subsumptive
     ((===shuowen-jiguge-A30 . 03111)	; &SW-JIGUGE30-03111;
      )
     ((===shuowen-jiguge5 . 03111)	; &SW-JIGUGE5-03111;
      )
     ((===shuowen-jiguge4 . 03111)	; &SW-JIGUGE4-03111;
      ))
    ))
(define-char
  '((shuowen-radical	. 13)	; 蓐
    (=ucs		. #x3D31A)	; 𽌚
    (=shuowen-jiguge	. 03112)	; 𽌚
    (<-Small-Seal@shuowen
     ((=ucs		  . #x26D62)	; 𦵢
      ))
    (<-Zhouwen@shuowen
     ((=ucs		  . #x3D319)	; 𽌙
      )
     ((=ucs		  . #x8585)	; 薅
      ))
    (->subsumptive
     ((===shuowen-jiguge-A30 . 03112)	; &SW-JIGUGE30-03112;
      )
     ((===shuowen-jiguge5 . 03112)	; &SW-JIGUGE5-03112;
      )
     ((===shuowen-jiguge4 . 03112)	; &SW-JIGUGE4-03112;
      ))
    ))
(define-char
  '((shuowen-radical	. 13)	; 蓐
    (=ucs		. #x3D31B)	; 𽌛
    (=shuowen-jiguge	. 03113)	; 𽌛
    (<-Small-Seal@shuowen
     ((=ucs		  . #x8320)	; 茠
      ))
    (<-formed@shuowen
     ((=ucs		  . #x3D319)	; 𽌙
      )
     ((=ucs		  . #x8585)	; 薅
      ))
    (->subsumptive
     ((===shuowen-jiguge-A30 . 03113)	; &SW-JIGUGE30-03113;
      )
     ((===shuowen-jiguge5 . 03113)	; &SW-JIGUGE5-03113;
      )
     ((===shuowen-jiguge4 . 03113)	; &SW-JIGUGE4-03113;
      ))
    ))
