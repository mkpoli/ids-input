;; -*- coding: utf-8-mcs-er -*-
(define-char
  '((shuowen-radical	. 10)	; 丨
    (=ucs		. #x3D118)	; 𽄘
    (=shuowen-jiguge	. 01307)	; 𽄘
    (<-Small-Seal@shuowen
     ((=ucs		  . #x4E28)	; 丨
      ))
    (->subsumptive
     ((===shuowen-jiguge-A30 . 01307)	; &SW-JIGUGE30-01307;
      )
     ((===shuowen-jiguge5 . 01307)	; &SW-JIGUGE5-01307;
      )
     ((===shuowen-jiguge4 . 01307)	; &SW-JIGUGE4-01307;
      ))
    ))
(define-char
  '((shuowen-radical	. 10)	; 丨
    (=ucs		. #x3D119)	; 𽄙
    (=shuowen-jiguge	. 01308)	; 𽄙
    (<-Small-Seal@shuowen
     ((=ucs		  . #x4E2D)	; 中
      ))
    (->subsumptive
     ((===shuowen-jiguge-A30 . 01308)	; &SW-JIGUGE30-01308;
      )
     ((===shuowen-jiguge5 . 01308)	; &SW-JIGUGE5-01308;
      )
     ((===shuowen-jiguge4 . 01308)	; &SW-JIGUGE4-01308;
      ))
    ))
(define-char
  '((shuowen-radical	. 10)	; 丨
    (=ucs		. #x3D11A)	; 𽄚
    (=shuowen-jiguge	. 01309)	; 𽄚
    (<-Small-Seal@shuowen
     ((=ucs		  . #x20067)	; 𠁧
      )
     ((=ucs		  . #x20066)	; 𠁦
      ))
    (->subsumptive
     ((===shuowen-jiguge-A30 . 01309)	; &SW-JIGUGE30-01309;
      )
     ((===shuowen-jiguge5 . 01309)	; &SW-JIGUGE5-01309;
      )
     ((===shuowen-jiguge4 . 01309)	; &SW-JIGUGE4-01309;
      ))
    ))
(define-char
  '((shuowen-radical	. 10)	; 丨
    (=ucs		. #x3D11B)	; 𽄛
    (=shuowen-jiguge	. 01310)	; 𽄛
    (<-Small-Seal@shuowen
     ((=ucs		  . #x20069)	; 𠁩
      ))
    (->subsumptive
     ((===shuowen-jiguge-A30 . 01310)	; &SW-JIGUGE30-01310;
      )
     ((===shuowen-jiguge5 . 01310)	; &SW-JIGUGE5-01310;
      )
     ((===shuowen-jiguge4 . 01310)	; &SW-JIGUGE4-01310;
      ))
    ))
(define-char
  '((shuowen-radical	. 10)	; 丨
    (ideographic-structure
     ((name . "IDEOGRAPHIC DESCRIPTION CHARACTER SURROUND FROM UPPER LEFT")
      (=ucs		  . #x2FF8)	; ⿸
      )
     ((=shuowen-jiguge	  . 22711)	; &SW-JIGUGE-22711;
      )
     ((=ucs		  . #x3D118)	; 𽄘
      ))
    (=ucs		. #x3D11C)	; 𽄜
    (=shuowen-jiguge	. 01311)	; 𽄜
    (<-Small-Seal@shuowen
     ((=ucs		  . #x230D8)	; 𣃘
      ))
    (->subsumptive
     ((===shuowen-jiguge-A30 . 01311)	; &SW-JIGUGE30-01311;
      )
     ((===shuowen-jiguge5 . 01311)	; &SW-JIGUGE5-01311;
      )
     ((===shuowen-jiguge4 . 01311)	; &SW-JIGUGE4-01311;
      ))
    ))
