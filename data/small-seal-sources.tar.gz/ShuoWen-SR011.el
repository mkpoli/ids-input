;; -*- coding: utf-8-mcs-er -*-
(define-char
  '((shuowen-radical	. 11)	; 屮
    (=ucs		. #x3D11D)	; 𽄝
    (=shuowen-jiguge	. 01400)	; 𽄝
    (<-Small-Seal@shuowen
     ((=ucs		  . #x5C6E)	; 屮
      ))
    (->subsumptive
     ((===shuowen-jiguge-A30 . 01400)	; &SW-JIGUGE30-01400;
      )
     ((===shuowen-jiguge5 . 01400)	; &SW-JIGUGE5-01400;
      )
     ((===shuowen-jiguge4 . 01400)	; &SW-JIGUGE4-01400;
      ))
    ))
(define-char
  '((shuowen-radical	. 11)	; 屮
    (=ucs		. #x3D11E)	; 𽄞
    (=shuowen-jiguge	. 01500)	; 𽄞
    (<-Small-Seal@shuowen
     ((=ucs		  . #x5C6F)	; 屯
      ))
    (->subsumptive
     ((===shuowen-jiguge-A30 . 01500)	; &SW-JIGUGE30-01500;
      )
     ((===shuowen-jiguge5 . 01500)	; &SW-JIGUGE5-01500;
      )
     ((===shuowen-jiguge4 . 01500)	; &SW-JIGUGE4-01500;
      ))
    ))
(define-char
  '((shuowen-radical	. 11)	; 屮
    (ideographic-structure
     ((name . "IDEOGRAPHIC DESCRIPTION CHARACTER ABOVE TO BELOW")
      (=ucs		  . #x2FF1)	; ⿱
      )
     ((=ucs		  . #x3D11D)	; 𽄝
      )
     ((=shuowen-jiguge	  . 43002)	; &SW-JIGUGE-43002;
      ))
    (=ucs		. #x3D11F)	; 𽄟
    (=shuowen-jiguge	. 01501)	; 𽄟
    (<-Small-Seal@shuowen
     ((=ucs		  . #x21D0B)	; 𡴋
      )
     ((=ucs		  . #x6BCF)	; 每
      )
     ((=>ucs@iwds-1	  . #x6BCF)	; &J97-4B68;
      (=>jis-x0208@1997	  . #x4B68)	; &J97-4B68; [43-72]
      )
     ((=ucs		  . #x6BCE)	; 毎
      ))
    (->subsumptive
     ((===shuowen-jiguge-A30 . 01501)	; &SW-JIGUGE30-01501;
      )
     ((===shuowen-jiguge5 . 01501)	; &SW-JIGUGE5-01501;
      )
     ((===shuowen-jiguge4 . 01501)	; &SW-JIGUGE4-01501;
      ))
    ))
(define-char
  '((shuowen-radical	. 11)	; 屮
    (ideographic-structure
     ((name . "IDEOGRAPHIC DESCRIPTION CHARACTER ABOVE TO BELOW")
      (=ucs		  . #x2FF1)	; ⿱
      )
     ((=ucs		  . #x3D11D)	; 𽄝
      )
     ((=shuowen-jiguge	  . 43723)	; &SW-JIGUGE-43723;
      ))
    (=ucs		. #x3D120)	; 𽄠
    (=shuowen-jiguge	. 01502)	; 𽄠
    (<-Small-Seal@shuowen
     ((=ucs		  . #x21D1B)	; 𡴛
      )
     ((=ucs		  . #x21E46)	; 𡹆
      )
     ((=ucs		  . #x6BD2)	; 毒
      ))
    (->subsumptive
     ((===shuowen-jiguge-A30 . 01502)	; &SW-JIGUGE30-01502;
      )
     ((===shuowen-jiguge5 . 01502)	; &SW-JIGUGE5-01502;
      )
     ((===shuowen-jiguge4 . 01502)	; &SW-JIGUGE4-01502;
      ))
    ))
(define-char
  '((shuowen-radical	. 11)	; 屮
    (=>shuowen-jiguge	. 01503)	; &A-SW-JIGUGE-01503;
    (<-Small-Seal@shuowen
     ((=ucs		  . #x26E15)	; 𦸕
      )
     ((=ucs		  . #x25CAE)	; 𥲮
      ))
    ))
(define-char
  '((<-denotational
     ((=>shuowen-jiguge	  . 01503)	; &A-SW-JIGUGE-01503;
      ))
    (shuowen-radical	. 11)	; 屮
    (ideographic-structure
     ((name . "IDEOGRAPHIC DESCRIPTION CHARACTER SURROUND FROM UPPER LEFT")
      (=ucs		  . #x2FF8)	; ⿸
      )
     ((=ucs		  . #x3D1B4)	; 𽆴
      )
     ((=shuowen-jiguge	  . 14010)	; &SW-JIGUGE-14010;
      ))
    (=ucs		. #x3D121)	; 𽄡
    (=shuowen-jiguge	. 01503)	; 𽄡
    (<-Small-Seal@shuowen
     ((=ucs		  . #x26E15)	; 𦸕
      ))
    (<-ancient@shuowen
     ((=ucs		  . #x3D120)	; 𽄠
      )
     ((=ucs		  . #x6BD2)	; 毒
      ))
    (->subsumptive
     ((===shuowen-jiguge-A30 . 01503)	; &SW-JIGUGE30-01503;
      )
     ((===shuowen-jiguge5 . 01503)	; &SW-JIGUGE5-01503;
      )
     ((===shuowen-jiguge4 . 01503)	; &SW-JIGUGE4-01503;
      ))
    ))
(define-char
  '((<-denotational
     ((=>shuowen-jiguge	  . 01503)	; &A-SW-JIGUGE-01503;
      ))
    (shuowen-radical	. 11)	; 屮
    (=ucs		. #x3D122)	; 𽄢
    (<-Small-Seal@shuowen
     ((=ucs		  . #x25CAE)	; 𥲮
      ))
    ))
(define-char
  '((shuowen-radical	. 11)	; 屮
    (ideographic-structure
     ((name . "IDEOGRAPHIC DESCRIPTION CHARACTER ABOVE TO BELOW")
      (=ucs		  . #x2FF1)	; ⿱
      )
     ((=ucs		  . #x3D11D)	; 𽄝
      )
     ((=ucs		  . #x3D324)	; 𽌤
      ))
    (=ucs		. #x3D123)	; 𽄣
    (=shuowen-jiguge	. 01504)	; 𽄣
    (<-Small-Seal@shuowen
     ((=ucs		  . #x37A3)	; 㞣
      ))
    (->subsumptive
     ((===shuowen-jiguge-A30 . 01504)	; &SW-JIGUGE30-01504;
      )
     ((===shuowen-jiguge5 . 01504)	; &SW-JIGUGE5-01504;
      )
     ((===shuowen-jiguge4 . 01504)	; &SW-JIGUGE4-01504;
      ))
    ))
(define-char
  '((shuowen-radical	. 11)	; 屮
    (ideographic-structure
     ((name . "IDEOGRAPHIC DESCRIPTION CHARACTER ABOVE TO BELOW")
      (=ucs		  . #x2FF1)	; ⿱
      )
     ((=ucs		  . #x3D128)	; 𽄨
      )
     ((=ucs		  . #x3D324)	; 𽌤
      ))
    (=ucs		. #x3D124)	; 𽄤
    (=shuowen-jiguge	. 01505)	; 𽄤
    (<-Small-Seal@shuowen
     ((=ucs		  . #x82AC)	; 芬
      )
     ((=ucs		  . #x21D1A)	; 𡴚
      ))
    (->subsumptive
     ((===shuowen-jiguge-A30 . 01505)	; &SW-JIGUGE30-01505;
      )
     ((===shuowen-jiguge5 . 01505)	; &SW-JIGUGE5-01505;
      )
     ((===shuowen-jiguge4 . 01505)	; &SW-JIGUGE4-01505;
      ))
    ))
(define-char
  '((shuowen-radical	. 11)	; 屮
    (ideographic-structure
     ((name . "IDEOGRAPHIC DESCRIPTION CHARACTER ABOVE TO BELOW")
      (=ucs		  . #x2FF1)	; ⿱
      )
     ((=ucs		  . #x3D11D)	; 𽄝
      )
     ((=shuowen-jiguge	  . 15300)	; &SW-JIGUGE-15300;
      ))
    (=ucs		. #x3D125)	; 𽄥
    (=shuowen-jiguge	. 01506)	; 𽄥
    (<-Small-Seal@shuowen
     ((=ucs		  . #x21D06)	; 𡴆
      )
     ((=ucs		  . #x5725)	; 圥
      ))
    (->subsumptive
     ((===shuowen-jiguge-A30 . 01506)	; &SW-JIGUGE30-01506;
      )
     ((===shuowen-jiguge5 . 01506)	; &SW-JIGUGE5-01506;
      )
     ((===shuowen-jiguge4 . 01506)	; &SW-JIGUGE4-01506;
      ))
    ))
(define-char
  '((shuowen-radical	. 11)	; 屮
    (ideographic-structure
     ((name . "IDEOGRAPHIC DESCRIPTION CHARACTER ABOVE TO BELOW")
      (=ucs		  . #x2FF1)	; ⿱
      )
     ((=ucs		  . #x3D125)	; 𽄥
      )
     ((ideographic-structure
       ((name . "IDEOGRAPHIC DESCRIPTION CHARACTER LEFT TO RIGHT")
	(=ucs		    . #x2FF0)	; ⿰
	)
       ((=ucs		    . #x3D125)	; 𽄥
	)
       ((=ucs		    . #x3D125)	; 𽄥
	))
      ))
    (=ucs		. #x3D126)	; 𽄦
    (=shuowen-jiguge	. 01507)	; 𽄦
    (<-Small-Seal@shuowen
     ((=ucs		  . #x21D2B)	; 𡴫
      )
     ((=ucs		  . #x21D2A)	; 𡴪
      )
     ((=ucs		  . #x204B6)	; 𠒶
      ))
    (<-Zhouwen@shuowen
     ((=ucs		  . #x3D125)	; 𽄥
      )
     ((=ucs		  . #x21D06)	; 𡴆
      )
     ((=ucs		  . #x5725)	; 圥
      ))
    (->subsumptive
     ((===shuowen-jiguge-A30 . 01507)	; &SW-JIGUGE30-01507;
      )
     ((===shuowen-jiguge5 . 01507)	; &SW-JIGUGE5-01507;
      )
     ((===shuowen-jiguge4 . 01507)	; &SW-JIGUGE4-01507;
      ))
    ))
(define-char
  '((shuowen-radical	. 11)	; 屮
    (ideographic-structure
     ((name . "IDEOGRAPHIC DESCRIPTION CHARACTER ABOVE TO BELOW")
      (=ucs		  . #x2FF1)	; ⿱
      )
     ((=ucs		  . #x3D11D)	; 𽄝
      )
     ((=shuowen-jiguge	  . 35015)	; &SW-JIGUGE-35015;
      ))
    (=ucs		. #x3D127)	; 𽄧
    (=shuowen-jiguge	. 01508)	; 𽄧
    (<-Small-Seal@shuowen
     ((=ucs		  . #x21F7D)	; 𡽽
      )
     ((=ucs		  . #x21D26)	; 𡴦
      )
     ((=ucs		  . #x718F)	; 熏
      ))
    (->subsumptive
     ((===shuowen-jiguge-A30 . 01508)	; &SW-JIGUGE30-01508;
      )
     ((===shuowen-jiguge5 . 01508)	; &SW-JIGUGE5-01508;
      )
     ((===shuowen-jiguge4 . 01508)	; &SW-JIGUGE4-01508;
      ))
    ))
