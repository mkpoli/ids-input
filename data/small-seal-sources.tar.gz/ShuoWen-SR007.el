;; -*- coding: utf-8-mcs-er -*-
(define-char
  '((shuowen-radical	. 7)	; 玨
    (ideographic-structure
     ((name . "IDEOGRAPHIC DESCRIPTION CHARACTER LEFT TO RIGHT")
      (=ucs		  . #x2FF0)	; ⿰
      )
     ((=ucs		  . #x3D06D)	; 𽁭
      )
     ((=ucs		  . #x3D06D)	; 𽁭
      ))
    (=ucs		. #x3D10C)	; 𽄌
    (=shuowen-jiguge	. 01215)	; 𽄌
    (<-Small-Seal@shuowen
     ((=ucs		  . #x73CF)	; 珏
      )
     ((=ucs		  . #x73A8)	; 玨
      ))
    (->subsumptive
     ((===shuowen-jiguge-A30 . 01215)	; &SW-JIGUGE30-01215;
      )
     ((===shuowen-jiguge5 . 01215)	; &SW-JIGUGE5-01215;
      )
     ((===shuowen-jiguge4 . 01215)	; &SW-JIGUGE4-01215;
      ))
    ))
(define-char
  '((shuowen-radical	. 7)	; 玨
    (ideographic-structure
     ((name . "IDEOGRAPHIC DESCRIPTION CHARACTER SURROUND FROM ABOVE")
      (=ucs		  . #x2FF5)	; ⿵
      )
     ((=shuowen-jiguge	  . 09412)	; &SW-JIGUGE-09412;
      )
     ((=ucs		  . #x3D06D)	; 𽁭
      ))
    (=ucs		. #x3D10D)	; 𽄍
    (=shuowen-jiguge	. 01216)	; 𽄍
    (<-Small-Seal@shuowen
     ((=ucs		  . #x7474)	; 瑴
      ))
    (<-formed@shuowen
     ((=ucs		  . #x3D10C)	; 𽄌
      )
     ((=ucs		  . #x73CF)	; 珏
      ))
    (->subsumptive
     ((===shuowen-jiguge-A30 . 01216)	; &SW-JIGUGE30-01216;
      )
     ((===shuowen-jiguge5 . 01216)	; &SW-JIGUGE5-01216;
      )
     ((===shuowen-jiguge4 . 01216)	; &SW-JIGUGE4-01216;
      ))
    ))
(define-char
  '((shuowen-radical	. 7)	; 玨
    (ideographic-structure
     ((name . "IDEOGRAPHIC DESCRIPTION CHARACTER FULL SURROUND")
      (=ucs		  . #x2FF4)	; ⿴
      )
     ((=ucs		  . #x3D10C)	; 𽄌
      )
     ((=shuowen-jiguge	  . 14010)	; &SW-JIGUGE-14010;
      ))
    (=ucs		. #x3D10E)	; 𽄎
    (=shuowen-jiguge	. 01217)	; 𽄎
    (<-Small-Seal@shuowen
     ((=ucs		  . #x2493B)	; 𤤻
      )
     ((=ucs		  . #x73ED)	; 班
      ))
    (->subsumptive
     ((===shuowen-jiguge-A30 . 01217)	; &SW-JIGUGE30-01217;
      )
     ((===shuowen-jiguge5 . 01217)	; &SW-JIGUGE5-01217;
      )
     ((===shuowen-jiguge4 . 01217)	; &SW-JIGUGE4-01217;
      ))
    ))
(define-char
  '((shuowen-radical	. 7)	; 玨
    (ideographic-structure
     ((name . "IDEOGRAPHIC DESCRIPTION CHARACTER FULL SURROUND")
      (=ucs		  . #x2FF4)	; ⿴
      )
     ((=ucs		  . #x3D10C)	; 𽄌
      )
     ((=shuowen-jiguge	  . 49806)	; &SW-JIGUGE-49806;
      ))
    (=ucs		. #x3D10F)	; 𽄏
    (=shuowen-jiguge	. 01218)	; 𽄏
    (<-Small-Seal@shuowen
     ((=ucs		  . #x28325)	; 𨌥
      ))
    (->subsumptive
     ((===shuowen-jiguge-A30 . 01218)	; &SW-JIGUGE30-01218;
      )
     ((===shuowen-jiguge5 . 01218)	; &SW-JIGUGE5-01218;
      )
     ((===shuowen-jiguge4 . 01218)	; &SW-JIGUGE4-01218;
      ))
    ))
